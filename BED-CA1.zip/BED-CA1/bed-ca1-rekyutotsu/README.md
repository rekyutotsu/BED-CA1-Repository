# Name: Mohamed Dani Bin Mohamed Kasim
# Admin No. : P2323093
# Class : DIT/1B/06

# Introduction
This is my CA1 assignment for BED. I've completed Section A, adding an additional endpoint to the userRoutes relating to the section B.
For my section B, I decided to make a game where users can create pets, choosing their type(such as a cat or dog), and level them up by
taking on quests by completing real life actions that benefit the environment, such as planting a tree, which would result in an in-game-reward such as feeding your pet, which is what helps it to level up. Each quest completed has an allocated amount of exp for the pet to gain and every 100
exp, the pet gains a level.

# Prerequisites

Make sure to have these dependencies downloaded before running the initialisation tables(initTables.js) via npm run init_tables

1. nodemon
2. express
3. mysql2
4. dotenv

# The Routes
1. users
2. tasks
3. task_progress
4. pets (Section B)
5. quests (Section B)
6. pet_ownerships (Section B)
7. pet_progress (Section B)

# Section B - Pets
Here are all the endpoints under /pets:

1. /post '/'
- To create a new pet
- Example request body:
{
    "type": "Dog",
    "name": "Jonathan"
}

2. /get '/:id'
- To get the desired pet's info, including type, name, birthday, total exp, level owner_id, and the owner's username

3. /get '/'
- To get all pets' info, including type, name, birthday, level, total exp owner_id, and the owner's username

4. /put '/:id'
- To update a pet's info
- Example request body:
{
    "type": "Dog",
    "name": "Melvin"
}

5. /delete '/:id'
-To delete a pet (no request body needed)

# Section B - Quests
Here are all the endpoints under /quests:

1. /post '/'
- To create a new quest
- Example request body:
{
"in_game_reward": "feed pet beans",
"real_life_action": "recycle bottle",
"action_description": "dispose of a plastic bottle in a recycling bin",
"experience_points": 50
}

2. /get '/:id'
- To get the desired quest's info, including in_game_reward, real_life_action, action_description, experience_points

3. /get '/'
- To get all quests' info, including in_game_reward, real_life_action, action_description, experience_points

4. /put '/:id'
- To update a quest's info
- Example request body:
{
"in_game_reward": "put pet to sleep ",
"real_life_action": "avoid using plastic straws",
"action_description": "use a non-disposable straw such as a metal straw",
"experience_points": 30
}

5. /delete '/:id'
-To delete a quest (no request body needed)

# Section B - PetOwnership
Here are all the endpoints under /pet_ownership:

1. /post '/'
- To declare which pet belongs to which user, if a pet isn't registered under any user as its owner, the pet's owner id and name would be null by default.

- Example request body:
{
    "user_id": 1,
    "pet_id": 2
}

2. /get '/'
- To get all the ownership info, showing the owner's id and username, as well as the pet's id, type, name 

3. /get '/:id'
- To get a certain ownership info, showing the owner's id and username, as well as the pet's id, type, name 

# Section B - PetOwnership
Here are all the endpoints under /pet_ownership:

1. /post '/'
- To declare which rewards which pet will get, which will result in the pet getting exp to level it up

- Example request body:
{
    "pet_id": 2,
    "quest": 4
}

2. /get '/'
- To show all recorded quests completed and which pets will be getting the quest's rewards

3. /delete '/'
- To delete a certain recorded quest completed if it is falsely or accidentally recorded
