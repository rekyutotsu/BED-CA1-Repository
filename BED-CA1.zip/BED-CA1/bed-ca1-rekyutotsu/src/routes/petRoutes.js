const express = require('express');
const router = express.Router();

const controller = require('../controllers/petController');

router.post('/', controller.createNewPet);
router.get('/:id', controller.getPetById);
router.get('/', controller.getAllPets);
router.put('/:id', controller.updatePetById);
router.delete('/:id', controller.deletePetById);

module.exports = router;