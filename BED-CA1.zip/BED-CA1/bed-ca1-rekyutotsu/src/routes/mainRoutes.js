const express = require('express');
const router = express.Router();

const userRoutes = require('./userRoutes');
const taskRoutes = require('./taskRoutes');
const taskProgressRoutes = require('./taskProgressRoutes');
const petRoutes = require('./petRoutes');
const questRoutes = require('./questRoutes');
const petOwnershipRoutes = require('./petOwnershipRoutes');
const petProgressRoutes = require('./petProgressRoutes');

router.use("/users", userRoutes );
router.use("/tasks", taskRoutes );
router.use("/task_progress", taskProgressRoutes );
router.use("/pets", petRoutes );
router.use("/quests", questRoutes);
router.use("/pet_ownerships", petOwnershipRoutes);
router.use("/pet_progress", petProgressRoutes);

module.exports = router;