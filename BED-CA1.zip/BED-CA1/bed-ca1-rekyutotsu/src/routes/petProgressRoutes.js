const express = require('express');
const router = express.Router();

const controller = require('../controllers/petProgressController');

router.post('/', controller.verifyPetProgressData, controller.createNewPetProgress);
router.get('/', controller.getAllPetProgress);
router.delete('/:id', controller.deletePetProgressById);

module.exports = router;