const express = require('express');
const router = express.Router();

const controller = require('../controllers/userController');

router.post('/', controller.createNewUser);
router.get('/pets/:id', controller.getAllUserPets);
router.get('/:id', controller.readUserById);
router.get('/', controller.readAllUsers);
router.put('/:id', controller.updateUserById);
router.delete('/:id', controller.deleteUserById);

module.exports = router;