const model = require('../models/petProgressModel.js');

module.exports.verifyPetProgressData = (req, res, next) => {
    const pet_id = req.body.pet_id;
    const quest_id = req.body.quest_id;

    model.verifyPetQuestExistenceMiddleware(pet_id, quest_id, (results) => {
        const petResult = results[0];
        const questResult = results[1];

        if (petResult.length == 0) {
            res.status(404).json({ message: "pet not found", status: 404 });
        } else if (questResult.length == 0) {
            res.status(404).json({ message: "quest not found", status: 404 });
        } else {
            // Check if completion_date is provided
            if (pet_id == undefined || quest_id == undefined ) {
                res.status(400).json({
                    error: 'Bad Request',
                    message: 'pet_id or quest_id is missing in the request body',
                });
            } else {
                next();
            }
        }
    });
};

module.exports.createNewPetProgress = (req, res, next) => {
    if (req.body.pet_id == undefined || req.body.quest_id == undefined) {
        res.status(400).json({
            error: 'Bad Request', message: 'pet_id or quest_id is missing in the request body',
        });
        return;
    }

    const data = {
        pet_id: req.body.pet_id,
        quest_id: req.body.quest_id
    };

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            const petProgress_id = results.insertId;
            const dataResponse = {
                petProgress_id,
                ...data,
            };

            res.status(201).json(dataResponse);
        }
    };

    model.insertSinglePetProgress(data, callback);
};

module.exports.getAllPetProgress = (req, res, next) => {
    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            res.status(200).json(results);
        }
    };

    model.selectAllPetProgress(callback);
};

module.exports.deletePetProgressById = (req, res, next) => {
    const pet_progress_id = req.params.id;

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if (results.affectedRows == 0) {
                res.status(404).json({
                    error: 'Not Found',
                    message: "Error: pet progress id not found"
                });
            } else {
                res.status(204).send(); // 204 No Content
            }
        }
    };

    model.deletePetProgressById(pet_progress_id, callback);
};