const model = require('../models/userModel.js');

module.exports.createNewUser = (req, res, next) => {
    if (req.body.username == undefined || req.body.email == undefined) {
        res.status(400).json({ error: 'Bad Request', message: 'Username or Email is undefined' });
        return;
    }

    const data = {
        username: req.body.username,
        email: req.body.email,
    };

    const checkExistingUserCallback = (error, results, fields) => {
        // Check if the email already exists
        if (results.length > 0) {
            res.status(409).json({ error: 'Conflict', message: 'Email already exists' });
        } else {
            // If the email is unique, proceed with user creation
            const insertUserCallback = (error, results, fields) => {
                if (error) {
                    console.error("Error creating new user:", error);
                    res.status(500).json(error);
                } else {
                    const user_id = results.insertId;
                    const dataResponse = {
                        user_id,
                        username: data.username,
                        email: data.email,
                    };
                    res.status(201).json(dataResponse);
                }
            };

            // Insert new user into the database
            model.insertSingle(data, insertUserCallback);
        }
    };

    // Check if the email already exists in the database
    model.selectByEmail(data.email, checkExistingUserCallback);
};

module.exports.readAllUsers = (req, res, next) => {
    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readAllUser:", error);
            res.status(500).json(error);
        }
        else res.status(200).json(results);
    }

    model.selectAll(callback);
};

function calculateTotalPoints(user_id, callback){
    model.selectTotalPointsByUserId(user_id, (error, result) => {
        if (error) {
            callback(error);
        } else {
            // Extract total points from the result or default to 0
            let totalPoints;
            if (result.length > 0) {
                totalPoints = result[0].total_points;
            } else {
                totalPoints = 0;
            }
            callback(null, totalPoints);
        }
    });
};

// Controller function to read user details by ID
module.exports.readUserById = (req, res, next) => {
    const user_id = req.params.id;

    // Callback to handle the result of calculating total points
    const totalPointsCalculation = (error, totalPoints) => {
        if (error) {
            res.status(500).json(error);
        } else {
            model.selectById(user_id, (error, results, fields) => {
                if (error) {
                    res.status(500).json(error);
                } else if (results.length == 0) {
                    res.status(404).json({message: "User not found" });
                } else {
                    const user = results[0];
                    // Calculate total points and add it to the responseObject
                    let total_points;
                    if (totalPoints == null) {
                        total_points = 0;
                    } else {
                        total_points = totalPoints;
                    }
                    const dataResponse = {
                        user_id: user.user_id,
                        username: user.username,
                        email: user.email,
                        total_points: total_points,
                    };
                    res.status(200).json(dataResponse);
                }
            });
        }
    };

    // Call the function to calculate total points
    calculateTotalPoints(user_id, totalPointsCalculation);
};

module.exports.updateUserById = (req, res, next) => {
    if (req.body.username == undefined || req.body.email == undefined) {
        res.status(400).json({
            message: "Error: name or email is undefined"
        });
        return;
    }

    const data = {
        user_id: req.params.id,
        username: req.body.username,
        email: req.body.email,
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error updateUserById:", error);
            res.status(500).json(error);
        } else {
            if (results.affectedRows == 0) {
                res.status(404).json({
                    error: 'Not Found',
                    message: "Error: user is not found"
                });
            }
            else res.status(201).send(data); // 204 No Content
        }
    }

    model.updateById(data, callback);
};

module.exports.deleteUserById = (req, res, next) => {
    const user_id = req.params.id;

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error deleteUserById:", error);
            res.status(500).json(error);
        } else {
            if (results.affectedRows == 0) {
                res.status(404).json({
                    error: 'Not Found',
                    message: "Error: user is not found"
                });
            } else {
                res.status(204).send(); // 204 No Content
            }
        }
    };

    model.deleteById(user_id, callback);
};

module.exports.getAllUserPets = (req, res, next) => {
    const user_id = req.params.id;

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            res.status(200).json(results);
        }
    };

    model.selectAllUserPets(user_id, callback);
};