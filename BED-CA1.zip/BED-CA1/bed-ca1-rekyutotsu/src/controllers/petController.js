const model = require('../models/petModel.js');

module.exports.createNewPet = (req, res, next) => {
    if (req.body.type == undefined || req.body.name == undefined) {
        res.status(400).json({
            error: 'Bad Request', message: 'Your pet\'s name or type is missing in the request body',
        });
        return;
    }

    const data = {
        type: req.body.type,
        name: req.body.name
    };

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            const pet_id = results.insertId;
            const dataResponse = {
                pet_id,
                ...data,
            };

            res.status(201).json(dataResponse);
        }
    };

    model.insertSinglePet(data, callback);
};

module.exports.getAllPets = (req, res, next) => {
    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            res.status(200).json(results);
        }
    };

    model.selectAllPets(callback);
};

module.exports.getPetById = (req, res, next) => {
    const pet_id = req.params.id;

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if (results.length == 0) {
                res.status(404).json({
                    error: 'Not Found',
                    message: "Error: pet not found"
                });
            } else {
                const petData = results[0];

                // Calculate total experience points
                calculateTotalExperience(petData.pet_id, (error, totalExperience) => {
                    if (error) {
                        res.status(500).json(error);
                    } else {
                        petData.total_experience_points = totalExperience;
                        const level = Math.floor(totalExperience / 100);
                        const experience_points_left_to_level_up = (100 * (level + 1) - totalExperience)
                        const dataResponse = {
                            ...petData,
                            experience_points_left_to_level_up,
                            level
                        };
                        res.status(200).json(dataResponse);
                    }
                });
            }
        }
    };

    model.selectPetById(pet_id, callback);
};

// Helper function to calculate total experience points for a pet
function calculateTotalExperience(pet_id, callback) {
    model.selectLinkedQuests(pet_id, (questError, questResults) => {
        if (questError) {
            return callback(questError, null);
        }

        // Sum up the experience points from linked quests
        const totalExperience = questResults.reduce((total, quest) => total + quest.experience_points, 0);
        callback(null, totalExperience);
    });
}


module.exports.updatePetById = (req, res, next) => {
    if (req.body.type == undefined || req.body.name == undefined) {
        res.status(400).json({
            error: 'Bad Request',
            message: 'Pet\'s name or type is missing',
        });
        return;
    }

    const data = {
        pet_id: req.params.id,
        type: req.body.type,
        name: req.body.name
    };

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if (results.affectedRows == 0) {
                res.status(404).json({
                    error: 'Not Found',
                    message: "Error: pet not found"
                });
            } else {
                res.status(200).json(data);
            }
        }
    };

    model.updatePetById(data, callback);
};

module.exports.deletePetById = (req, res, next) => {
    const pet_id = req.params.id;

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if (results.affectedRows == 0) {
                res.status(404).json({
                    error: 'Not Found',
                    message: "Error: task not found"
                });
            } else {
                res.status(204).send(); // 204 No Content
            }
        }
    };

    model.deletePetById(pet_id, callback);
};