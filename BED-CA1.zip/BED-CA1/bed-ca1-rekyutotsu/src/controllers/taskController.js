const model = require('../models/taskModel.js');

module.exports.createNewTask = (req, res, next) => {
    // Check if title, description, and points are provided in the request body
    if (req.body.title == undefined || req.body.description == undefined || req.body.points == undefined) {
        res.status(400).json({
            error: 'Bad Request', message: 'Title, description, or points is missing in the request body',
        });
        return;
    }

    const data = {
        title : req.body.title,
        description: req.body.description,
        points : req.body.points,
    };

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            const task_id = results.insertId;
            const dataResponse = {
                task_id,
                ...data,
            };

            res.status(201).json(dataResponse);
        }
    };

    model.insertSingle(data, callback);
};

module.exports.getAllTasks = (req, res, next) => {
    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            res.status(200).json(results);
        }
    };

    model.selectAll(callback);
};

module.exports.getTaskById = (req, res, next) => {
    const task_id = req.params.id;

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if (results.length == 0) {
                res.status(404).json({
                    error: 'Not Found',
                    message: "Error: task not found"
                });
            } else {
                const task = results[0];
                res.status(200).json(task);
            }
        }
    };

    model.selectById(task_id, callback);
};

module.exports.updateTaskById = (req, res, next) => {
    // Check if title, description, or points is missing in the request body
    if (req.body.title == undefined || req.body.description == undefined || req.body.points == undefined) {
        res.status(400).json({
            error: 'Bad Request',
            message: 'Title or description or points is missing',
        });
        return;
    }

    const data = {
        task_id: req.params.id,
        title: req.body.title,
        description: req.body.description,
        points: req.body.points,
    };

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if (results.affectedRows == 0) {
                res.status(404).json({
                    error: 'Not Found',
                    message: "Error: task not found"
                });
            } else {
                res.status(200).json(data);
            }
        }
    };

    model.updateById(data, callback);
};

module.exports.deleteTaskById = (req, res, next) => {
    const task_id = req.params.id;

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if (results.affectedRows == 0) {
                res.status(404).json({
                    error: 'Not Found',
                    message: "Error: task not found"
                });
            } else {
                res.status(204).send(); // 204 No Content
            }
        }
    };

    model.deleteById(task_id, callback);
};