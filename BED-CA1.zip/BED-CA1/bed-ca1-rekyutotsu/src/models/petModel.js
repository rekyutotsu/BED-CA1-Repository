const pool = require('../services/db');

module.exports.insertSinglePet = (data, callback) => {
    const SQLSTATEMENT = `
        INSERT INTO Pet (type, name, birthday)
        VALUES (?, ?, CURRENT_TIMESTAMP);
    `;

    const VALUES = [data.type, data.name];

    pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.selectAllPets = (callback) => {
    const SQLSTATEMENT = `
        SELECT Pet.pet_id, Pet.type, Pet.name, Pet.birthday, User.user_id AS owner_id, User.username AS owner_username
        FROM Pet
        LEFT JOIN PetOwnership ON Pet.pet_id = PetOwnership.pet_id
        LEFT JOIN User ON PetOwnership.user_id = User.user_id;
    `;

    pool.query(SQLSTATEMENT, callback);
};

module.exports.selectPetById = (pet_id, callback) => {
    const SQLSTATEMENT = `
        SELECT Pet.pet_id, Pet.type, Pet.name, Pet.birthday, User.user_id AS owner_id, User.username AS owner_username
        FROM Pet
        LEFT JOIN PetOwnership ON Pet.pet_id = PetOwnership.pet_id
        LEFT JOIN User ON PetOwnership.user_id = User.user_id
        WHERE Pet.pet_id = ?;
    `;

    const VALUES = [pet_id];

    pool.query(SQLSTATEMENT, VALUES, callback);
};


module.exports.selectLinkedQuests = (pet_id, callback) => {
    const SQL_STATEMENT = `
        SELECT Quest.experience_points
        FROM Quest
        INNER JOIN PetOwnership ON PetOwnership.pet_id = ?
        INNER JOIN PetProgress ON PetProgress.pet_id = PetOwnership.pet_id
        WHERE Quest.quest_id = PetProgress.quest_id;
    `;

    const VALUES = [pet_id];

    pool.query(SQL_STATEMENT, VALUES, callback);
};

module.exports.updatePetById = (data, callback) => {
    const SQLSTATEMENT = `
        UPDATE Pet 
        SET type = ?, name = ?
        WHERE pet_id = ?;
    `;

    const VALUES = [data.type, data.name, data.pet_id];

    pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.deletePetById = (pet_id, callback) => {
    const SQLSTATEMENT = `
        DELETE FROM Pet
        WHERE pet_id = ?;
    `;

    const VALUES = [pet_id];

    pool.query(SQLSTATEMENT, VALUES, callback);
};