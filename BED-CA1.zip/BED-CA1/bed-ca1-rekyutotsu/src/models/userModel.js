const pool = require('../services/db');

module.exports.insertSingle = (data, callback) => {
  const SQLSTATEMENT = `
    INSERT INTO User (username, email)
    VALUES (?, ?)
  `;
  const VALUES = [data.username, data.email];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.selectByEmail = (email, callback) => {
    const SQLSTATEMENT = `
        SELECT * FROM User
        WHERE email = ?;
    `;

    const VALUES = [email];

    pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.selectAll = (callback) => {
  const SQLSTATEMENT = `
  SELECT * FROM User
  `;

  pool.query(SQLSTATEMENT, callback);
};

module.exports.selectById = (user_id, callback) => {
  const SQLSTATEMENT = `
      SELECT user_id, username, email
      FROM User
      WHERE user_id = ?;
  `;

  const VALUES = [user_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.selectTotalPointsByUserId = (user_id, callback) => {
  const SQL_STATEMENT = `
      SELECT SUM(Task.points) AS total_points
      FROM TaskProgress
      INNER JOIN Task ON TaskProgress.task_id = Task.task_id
      WHERE TaskProgress.user_id = ?;
  `;

  const VALUES = [user_id];

  // Use the connection pool to execute the query
  pool.query(SQL_STATEMENT, VALUES, callback);
};

module.exports.updateById = (data, callback) =>
{
    const SQLSTATMENT = `
    UPDATE User 
    SET username = ?, email = ?
    WHERE user_id = ?;
    `;
const VALUES = [data.username, data.email, data.user_id];

pool.query(SQLSTATMENT, VALUES, callback);
};

module.exports.deleteById = (user_id, callback) => {
    const SQLSTATEMENT = `
        DELETE FROM User 
        WHERE user_id = ?;
    `;

    const VALUES = [user_id];

    pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.selectAllUserPets = (user_id, callback) => {
  const SQLSTATEMENT = `
      SELECT Pet.pet_id, Pet.type, Pet.name, Pet.birthday
      FROM Pet
      LEFT JOIN PetOwnership ON Pet.pet_id = PetOwnership.pet_id
      WHERE PetOwnership.user_id = ?;
  `;

  const VALUES = [user_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};