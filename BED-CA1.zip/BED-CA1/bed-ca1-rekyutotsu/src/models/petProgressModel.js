const pool = require('../services/db');

module.exports.verifyPetQuestExistenceMiddleware = (pet_id, quest_id, callback) => {
    const SQL_STATEMENT = `
        SELECT *
        FROM Pet
        WHERE pet_id = ?;

        SELECT *
        FROM Quest
        WHERE quest_id = ?;
    `;

    const VALUES = [pet_id, quest_id];

    pool.query(SQL_STATEMENT, VALUES, (error, results) => {
        if (error) {
            callback(error);
        } else {
            callback(results);
        }
    });
};

module.exports.insertSinglePetProgress = (data, callback) => {
    const SQLSTATEMENT = `
        INSERT INTO PetProgress (pet_id, quest_id, completion_date)
        VALUES (?, ?, CURRENT_TIMESTAMP);
    `;

    const VALUES = [data.pet_id, data.quest_id];

    pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.selectAllPetProgress = (callback) => {
    const SQLSTATEMENT = `
    SELECT PetProgress.*, Quest.in_game_reward, Quest.experience_points
    FROM PetProgress
    INNER JOIN Quest ON PetProgress.quest_id = Quest.quest_id;
    `;

    pool.query(SQLSTATEMENT, callback);
};

module.exports.deletePetProgressById = (pet_progress_id, callback) => {
    const SQLSTATEMENT = `
        DELETE FROM PetProgress
        WHERE pet_progress_id = ?;
    `;

    const VALUES = [pet_progress_id];

    pool.query(SQLSTATEMENT, VALUES, callback);
};